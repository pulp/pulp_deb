
use AdminUtil;
use DSUtil qw(debug);
# load perldap
use Mozilla::LDAP::Conn;
use Mozilla::LDAP::Utils qw(normalizeDN);
use Mozilla::LDAP::API qw(:constant ldap_url_parse ldap_explode_dn);

my @old_brands = ({cap => 'Red Hat',
                   norm => 'redhat',
                   vend => 'Red Hat'},
                  {cap => 'Fedora',
                   norm => 'fedora',
                   vend => 'Fedora Project'});

my $admininf = (getInfs("admin"))[0];

my $newbrand = {cap => $admininf->{admin}->{Brand},
                norm => $admininf->{admin}->{NormBrand},
                vend => $admininf->{admin}->{Vendor}};

my @attrs = ("*", 'aci');
my $nsrootdn = "o=NetscapeRoot";
my $myhost = "";
my @mapoldnew = ();

sub sameBrand {
    my ($old, $new) = @_;
    return $old->{norm} eq $new->{norm};
}

sub replaceOldNewEntry {
    my ($ent, @ary) = @_;
    my $changes = 0;
    for my $attr (keys %{$ent}) {
        my @newvals = $ent->getValues($attr);
        for my $pat (@ary) {
            my $old = $pat->{old};
            my $new = $pat->{new};
            if ($pat->{attr}) {
                if (lc($attr) eq lc($pat->{attr})) {
                    map { $changes += s/$old/$new/g } @newvals;
                }
            } else {
                map { $changes += s/$old/$new/g } @newvals;
            }
        }
        $ent->setValues($attr, @newvals);
    }
    return $changes;
}

sub rebrandEntry {
    my ($ent, $old, $new) = @_;
    my $dn = $ent->getDN();
    my $changes = ($dn =~ s/cn=$old->{cap}/cn=$new->{cap}/);
    if ($ent->getDN() ne $dn) {
        # if we rebranded the dn
        $ent->{_olddn_} = $ent->getDN(); # save old dn
    }
    $ent->setDN($dn); # set new dn and rebrand
    $changes += replaceOldNewEntry($ent,
        {attr => 'nsvendor', old => $old->{vend}, new => $new->{vend}},
        {attr => 'nsslapd-pluginvendor', old => $old->{vend}, new => $new->{vend}},
        {old => "cn=$old->{cap}", new => "cn=$new->{cap}"},
        {old => "\@$old->{norm}-admin", new => "\@$new->{norm}-admin"},
        {old => "\@$old->{norm}-ds", new => "\@$new->{norm}-ds"},
        {old => "$old->{norm}-admin", new => "$new->{norm}-admin"},
        {old => "$old->{norm}-ds", new => "$new->{norm}-ds"},
        {old => "$old->{cap} Administration Server", new => "$new->{cap} Administration Server"},
        {old => "$old->{cap} Directory Server", new => "$new->{cap} Directory Server"});
    return $changes; # number of changed items
}

sub fixDupVals {
    my ($conn, $ent) = @_;
    my $rc;
    # as a result of our corrections above, we have some
    # duplicate values - let's remove them
    # this is a list of attributes that may have DN syntax
    # and are multi valued - we have to normalize them first
    my %mydnattrs = (owner => 'owner', roleoccupant => 'roleoccupant',
                     member => 'member', seealso => 'seealso',
                     uniquemember => 'uniquemember',
                     parentorganization => 'parentorganization',
                     secretary => 'secretary', manager => 'manager',
                     aliasedobjectname => 'aliasedobjectname',
                     associatedname => 'associatedname',
                     distinguishedname => 'distinguishedname',
                     documentauthor => 'documentauthor',
                     nsroledn => 'nsroledn',
                     nsadminsiedn => 'nsadminsiedn',
                     nsdirectoryinforef => 'nsdirectoryinforef',
                     mailenhanceduniquemember => 'mailenhanceduniquemember');
    my %skipattrs = (objectclass => 'objectclass');
    for my $attr (keys %{$ent}) {
        next if ($skipattrs{lc $attr});
        my @newvals = $ent->getValues($attr);
        my %uniq = ();
        # the keys of the uniq hash will be the normalized values
        # the hash table will just throw away dups, so the
        # resultant table will have as the keys the unique
        # normalized values, and will have as the values the
        # original unique un-normalized values
        if ($mydnattrs{lc $attr}) {
            %uniq = map { normalizeDN($_) => $_ } @newvals;
        } else {
            %uniq = map { lc $_ => $_ } @newvals;
        }
        $ent->setValues($attr, values %uniq);
    }
    if ($conn->update($ent)) {
        $rc = LDAP_SUCCESS;
    } else {
        $rc = $conn->getErrorCode();
    }
    return $rc;
}

sub rebrandAddCopy {
    my ($conn, $ent, $old, $new, $exists) = @_;
    return () if (!rebrandEntry($ent, $old, $new)); # already branded correctly
    $conn->add($ent);
    my $rc = $conn->getErrorCode();
    if ($rc == LDAP_TYPE_OR_VALUE_EXISTS) {
        $rc = fixDupVals($conn, $ent);
    }
    if ($rc != LDAP_SUCCESS) {
        if ($rc != LDAP_ALREADY_EXISTS) {
            # just bail - it's unlikely that we would get this error from
            # far down in the tree, if we didn't already get this at
            # the top level
            return ('error_adding_entry', $ent->getDN(), $conn->getErrorString());
        } else {
            debug(1, "Entry ", $ent->getDN(), " already exists - skipping\n");
        }
    }
    return ();
}

# delete the subtree starting from the passed entry
sub delete_all
{
    my ($conn, $dn) = @_;
    my $sentry = $conn->search($dn, "subtree", "(objectclass=*)", 0, ("dn"));
    my @mystack = ();
    while ($sentry) {
        push @mystack, $sentry->getDN();
        $sentry = $conn->nextEntry();
    }
    # reverse order
    my $dn = pop @mystack;
    while ($dn) {
        $conn->delete($dn);
        my $rc = $conn->getErrorCode();
        if ($rc != LDAP_SUCCESS) {
            debug(1, "ERROR: unable to delete entry $dn, error code: $rc:" . $conn->getErrorString() . "\n");
            return $rc;
        }
        $dn = pop @mystack;
    }
    return LDAP_SUCCESS;
}

sub entIsIsie {
    my $ent = shift;
    return grep {/nsapplication/i} $ent->getValues('objectclass');
}

sub rebrandEntries {
    my ($conn, $old, $new, $mapoldnew, @ents) = @_;
    my @errs;
    my @entstodel;
    for my $ent (@ents) {
        next if (!$ent);
        @errs = rebrandAddCopy($conn, $ent, $old, $new);
        if (@errs) {
            return @errs;
        }
        if ($ent->{_olddn_}) {
            push @{$mapoldnew}, {old => $ent->{_olddn_}, new => $ent->getDN()};
            push @entstodel, $ent;
        }
    }
    while (@entstodel) {
        my $ent = pop @entstodel;
        my $dn = $ent->{_olddn_};
        $conn->delete($dn);
        my $rc = $conn->getErrorCode();
        # cannot delete the entire tree rooted at the isie because that would
        # delete all instances if there are multiple ds instances
        # but for other entries such as the sie
        if (($rc == LDAP_NOT_ALLOWED_ON_NONLEAF)) {
            if (entIsIsie($ent)) {
                $rc = 0; # if the isie is empty after we have done all sies, we will delete it later
            } else {
                $rc = delete_all($conn, $dn);
            }
        }
        if (($rc != LDAP_SUCCESS) and ($rc != LDAP_NO_SUCH_OBJECT)) {
            return ('error_deleteall_entries', $dn, $conn->getErrorString());
        }
    }
    return ();
}

# see if there are any more instances under the old isie - if
# not, remove the isie
sub cleanupIsie {
    my ($conn, $isiedn) = @_;
    my $rc = LDAP_SUCCESS;
    $sie = $conn->search($isiedn, "one", "objectclass=netscapeServer");
    if (!$sie) {
        $rc = delete_all($conn, $isiedn);
        if ($rc) {
            return ('error_deleteall_entries', $isiedn, $conn->getErrorString())
        }
    }
    return ();
}

sub rebrandSieAndIsie {
    my ($conn, $filt, $mapoldnew) = @_;

    my @errs;

    my @sieary = ();
    my $sie;
    for ($sie = $conn->search($nsrootdn, "sub", $filt, 0, @attrs);
         $sie; $sie = $conn->nextEntry) {
        push @sieary, $sie;
    }
    for $sie (@sieary) {
        my $siedn = $sie->getDN();
        my @rdns = ldap_explode_dn($siedn, 0);
        my $isiedn = join(',', @rdns[-5..-1]);
        my $isie = $conn->search($isiedn, "base", '(objectclass=*)', 0, @attrs);

        # search for old brands
        for my $oldbrand (@old_brands) {
            next if (sameBrand($oldbrand, $newbrand));
            my @ents = ($isie, $sie);
            my $sieconf = "cn=configuration," . $siedn;
            for ($ent = $conn->search($sieconf, "sub", "objectclass=*", 0, @attrs);
                 $ent; $ent = $conn->nextEntry) {
                push @ents, $ent;
            }
            @errs = rebrandEntries($conn, $oldbrand, $newbrand, $mapoldnew, @ents);
            if (@errs) {
                return @errs;
            }
        }
        @errs = cleanupIsie($conn, $isiedn);
        if (@errs) {
            return @errs;
        }
        # remove the sie entries under ou=User Preferences, ou=%domain%, o=NetscapeRoot
        # they will be recreated
        $ent = $conn->search($nsrootdn, 'sub', "(|(ou=$siedn)(ou=\"$siedn\"))");
        if ($ent) {
            $conn->delete($ent->getDN());
            my $rc = $conn->getErrorCode();
            if ($rc) {
                return ('error_deleteall_entries', $ent->getDN(), $conn->getErrorString());
            }
        }
    }
    return ();
}

sub getSuffixList {
    my $conn = shift;
    my @suffixlist = ('cn=schema', 'cn=monitor', 'cn=config');
    for (my $ent = $conn->search('cn=mapping tree,cn=config', 'one', 'objectclass=*', 0, ('cn'));
         $ent; $ent = $conn->nextEntry) {
        # grab the first cn value in the entry that does not begin with a quote
        my @ary = grep {!/^[\"]/} $ent->getValues('cn');
        if (!@ary) {
            # could not find one without quotes - strip quotes
            my $dn = $ent->getValues('cn');
            $dn =~ s/^[\"]//;
            $dn =~ s/[\"]$//;
            push @suffixlist, $dn;
        } else {
            push @suffixlist, $ary[0];
        }
    }
    return @suffixlist;
}

sub rebrandConfFiles {
    my $configdir = shift;
    # start with the isie from the adm.conf
    # see if there is already a configds
    my $admConf = AdminUtil::getAdmConf("$configdir/admin-serv");

    if (!$admConf) {
        return ('error_reading_conffile', "$configdir/admin-serv/adm.conf", $!);
    }
    # now fix adm.conf and local.conf
    my $count = 0; # reset
    while (my ($key, $val) = each %{$admConf}) {
        for my $oldbrand (@old_brands) {
            next if (sameBrand($oldbrand, $newbrand));
            $count += ($val =~ s/cn=$oldbrand->{cap}/cn=$newbrand->{cap}/g); # fix DNs
            $count += ($val =~ s/\@$oldbrand->{norm}-admin/\@$newbrand->{norm}-admin/g); # fix jar names
            $count += ($val =~ s/\@$oldbrand->{norm}-ds/\@$newbrand->{norm}-ds/g); # fix jar names
            $admConf->{$key} = $val;
        }
    }
    if (($count > 0) and !AdminUtil::updateAdmConf($admConf, "$configdir/admin-serv")) {
        return ('error_updating_conffile', "$configdir/admin-serv/adm.conf", $!);
    }

    my $localconf = "$configdir/admin-serv/local.conf";
    if (-f $localconf) {
        if (!open(LOCALCONF, "$localconf")) {
            return ('error_reading_conffile', $localconf, $!);
        }
        my @lines = <LOCALCONF>;
        close LOCALCONF;
        $count = 0; # reset
        for my $line (@lines) {
            for my $oldbrand (@old_brands) {
                next if (sameBrand($oldbrand, $newbrand));
                $count += ($line =~ s/cn=$oldbrand->{cap}/cn=$newbrand->{cap}/g); # fix DNs
                $count += ($line =~ s/\@$oldbrand->{norm}-admin/\@$newbrand->{norm}-admin/g); # fix jar names
                $count += ($line =~ s/\@$oldbrand->{norm}-ds/\@$newbrand->{norm}-ds/g); # fix jar names
            }
        }

        if ($count > 0) {
            if (!open(LOCALCONF, ">$localconf")) {
                return ('error_updating_conffile', $localconf, $!);
            }
            for my $line (@lines) {
                print LOCALCONF $line;
            }
            close LOCALCONF;
        }
    }
    return ();
}

sub postinst {
    my ($inf, $inst, $dseldif, $conn) = @_;
    my @errs;
    my $rc;
    if (!$myhost) {
        # we need to find the sie entry for the inst - we need
        # the host to do that
        my $config = "cn=config";
        my $config_entry = $conn->search($config, "base", "(objectclass=*)");
        if (!$config_entry) {
            return ("error_no_configuration_entry", $conn->getErrorString());
        }
        
        $myhost = $config_entry->getValues('nsslapd-localhost');
    }
    my $filt = "(&(cn=$inst)(serverhostname=$myhost))";
    my @localmapoldnew = ();
    my $cdsconn = $inf->{configdsconn};
    @errs = rebrandSieAndIsie($cdsconn, $filt, \@localmapoldnew);
    if (@errs) {
        return @errs;
    }
    # fix references to old sie and isie entries in ds instance
    # get a list of dns to search
    my @suffixlist = getSuffixList($conn);
    while (@suffixlist) {
        my $dn = pop @suffixlist;
        my $ent = $conn->search($dn, 'base', 'objectclass=*', 0, @attrs);
        if ($ent) {
            my $changes = replaceOldNewEntry($ent, @localmapoldnew);
            if ($changes and ($rc = fixDupVals($conn, $ent))) {
                return ('error_updating_entry', $ent->getDN(), $conn->getErrorString());
            }
        }
    }
    # add to the global mapoldnew
    push @mapoldnew, @localmapoldnew;

    return ();
}

sub post {
    my ($inf, $configdir) = @_;
    my @errs;
    my $rc;
    my $cdsconn = $inf->{configdsconn};

    # rebrand the admin server sie tree
    my $filt = "(&(serverhostname=$myhost)(objectClass=nsAdminServer))";
    @errs = rebrandSieAndIsie($cdsconn, $filt, \@mapoldnew);
    if (@errs) {
        return @errs;
    }

    # look through the entire tree looking for references to the old
    # dns - replace them with the new dns
    for (my $ent = $cdsconn->search($nsrootdn, 'sub', 'objectclass=*', 0, @attrs);
         $ent; $ent = $cdsconn->nextEntry) {
        my $changes = replaceOldNewEntry($ent, @mapoldnew);
        if ($changes and ($rc = fixDupVals($cdsconn, $ent))) {
            return ('error_updating_entry', $ent->getDN(), $cdsconn->getErrorString());
        }
    }

    # rebrand config files
    @errs = rebrandConfFiles($configdir);

    return @errs;
}
