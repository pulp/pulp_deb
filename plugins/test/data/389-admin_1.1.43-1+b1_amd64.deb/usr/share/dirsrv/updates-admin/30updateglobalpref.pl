# BEGIN COPYRIGHT BLOCK
# Copyright (C) 2009 Red Hat, Inc.
# All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; version 2
# of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
# END COPYRIGHT BLOCK

use DSUpdate;
use AdminUtil;
use DSUtil qw(debug);
# load perldap
use Mozilla::LDAP::Conn;
use Mozilla::LDAP::Utils qw(normalizeDN);
use Mozilla::LDAP::API qw(:constant ldap_url_parse ldap_explode_dn);

sub post {
    my ($inf, $configdir) = @_;

    my @infs = getInfs("setup", "admin");
    # there are several tokens in the map that we don't
    # use for 02globalpreferences - so just add dummy
    # values setupinf to make the map happy
    $setupinf->{General}->{ServerIdentifier} = 'notused';
    $setupinf->{General}->{ServerPort} = 'notused';
    $setupinf->{General}->{Suffix} = 'notused';

    my $upd = { path => '/usr/share/dirsrv/data/02globalpreferences.ldif.tmpl',
                mapper => "/usr/share/dirsrv/inf/updateconsoleinfo.map",
                infary => \@infs
              };
                   
    return DSUpdate::applyLDIFUpdate($upd, $inf->{configdsconn}, $inf);
}

# emacs settings
# Local Variables:
# mode:perl
# indent-tabs-mode: nil
# tab-width: 4
# End:
